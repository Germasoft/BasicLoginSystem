<?php

    //Just enter the information about your mysqli server
    $link = mysqli_connect("localhost", "USERNAME", "PASSWORD", "DATABASE-NAME");

?>